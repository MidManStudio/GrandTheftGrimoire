// ============================================================================
// NOTICE: Full documentation, design decisions, and fix history for this file
// live in docs/gtg-npc-ffi.md, section "gtg_npc.h"
// ============================================================================
#ifndef GTG_NPC_H
#define GTG_NPC_H
#include <stdint.h>

/* Must equal ABI_VERSION in rust/npc/crates/npc-ffi/src/lib.rs. */
#define GTG_NPC_ABI_VERSION 7u
#define GTG_NPC_MAX_BATCH 4096u
/* The highest Crown Heat tier: 0 none, 1 wanted, 2 hunted, 3 outlaw. A larger value is rejected. */
#define GTG_NPC_CROWN_HEAT_MAX 3u

/* Status codes returned by gtg_npc_decide_batch. */
#define GTG_NPC_OK 0
#define GTG_NPC_NULL -1     /* a pointer is null or not aligned */
#define GTG_NPC_CAPACITY -2 /* count above the maximum, or output smaller than input */
#define GTG_NPC_INVALID -3  /* unknown value, non-finite number, non-zero reserved field, or overlapping buffers */

/* Field values. The numbers are the ABI. */
#define GTG_NPC_ROLE_MERCHANT 0
#define GTG_NPC_ROLE_CIVILIAN 1
#define GTG_NPC_ROLE_GUARD 2
#define GTG_NPC_ROLE_ENEMY 3
#define GTG_NPC_ROLE_BOSS 4
#define GTG_NPC_ROLE_COMPANION 5
#define GTG_NPC_BACKEND_STATE_MACHINE 0
#define GTG_NPC_BACKEND_UTILITY 1
#define GTG_NPC_BACKEND_HYBRID_ML 2
#define GTG_NPC_DISPOSITION_HOSTILE 0
#define GTG_NPC_DISPOSITION_RETALIATORY 1
#define GTG_NPC_DISPOSITION_PEACEFUL 2
#define GTG_NPC_ATTACK_STYLE_MELEE 0
#define GTG_NPC_ATTACK_STYLE_RANGED 1
#define GTG_NPC_ATTACK_STYLE_HYBRID 2
#define GTG_NPC_ORDER_NONE 0
#define GTG_NPC_ORDER_FOLLOW 1
#define GTG_NPC_ORDER_HOLD 2
#define GTG_NPC_ORDER_ATTACK 3
#define GTG_NPC_ORDER_DELIVER 4
#define GTG_NPC_ORDER_RAID 5
#define GTG_NPC_ACTION_IDLE 0
#define GTG_NPC_ACTION_TRADE 1
#define GTG_NPC_ACTION_PATROL 2
#define GTG_NPC_ACTION_ATTACK 3
#define GTG_NPC_ACTION_RETREAT 4
#define GTG_NPC_ACTION_FOLLOW 5
#define GTG_NPC_ACTION_HOLD 6
#define GTG_NPC_ACTION_REFUSE_ORDER 7
#define GTG_NPC_ACTION_MISSION 8
#define GTG_NPC_ACTION_BETRAY 9
#define GTG_NPC_ACTION_SHOOT 10
#define GTG_NPC_ACTION_KITE 11
#define GTG_NPC_MISSION_SUCCESS 0
#define GTG_NPC_MISSION_FAILED 1
#define GTG_NPC_MISSION_CAUGHT 2
#define GTG_NPC_MISSION_KILLED 3

/* One NPC, 64 bytes. Booleans are 0 or 1. A zero in every field added after version 2 means: hostile, no order,
   not provoked, level 0, no betrayal opportunity, no Crown Heat, melee, nothing to shoot, not in a ranged stance,
   unknown distance to the threat, neutral favor.
   `threat_distance` is meters to the threat, finite, zero or less means unknown (offset 28 was a reserved word up
   to version 5). `attack_style`, `ranged_ready` and `ranged_stance` sit at offsets 57, 58 and 59 (reserved bytes
   up to version 5). `favor` at offset 60 is how much the NPC likes the player, finite, from -1 (hates) to 1 (adores),
   clamped to that range, zero is neutral (offset 60 was a reserved word up to version 6). Shopkeepers and civilians
   read it, no other role does. */
typedef struct {
    uint64_t npc_id;
    uint32_t role, backend, threat_visible;
    float health_fraction;
    uint32_t can_move;
    float threat_distance;
    uint8_t disposition, order, provoked, crown_heat;
    uint16_t level, order_level;
    float trustworthiness, affinity, pay_satisfaction;
    uint32_t noise;
    uint8_t betrayal_opportunity, attack_style, ranged_ready, ranged_stance;
    float favor;
} GtgNpcObservation;

/* One decision, 16 bytes. `reserved` is always zero. */
typedef struct { uint64_t npc_id; int32_t action; uint32_t reserved; } GtgNpcDecision;

uint32_t gtg_npc_abi_version(void);
uint32_t gtg_npc_observation_size(void);
uint32_t gtg_npc_decision_size(void);
/* How a mission that happens off screen ends: a GTG_NPC_MISSION_ value, or GTG_NPC_INVALID for an order that is
   not a mission (4 deliver or 5 raid) or a level above 65535. `noise` is a random number from the host. */
int32_t gtg_npc_resolve_mission(uint32_t order, uint32_t companion_level, uint32_t mission_level, uint32_t noise);
int32_t gtg_npc_decide_batch(const GtgNpcObservation *inputs, uint32_t count, GtgNpcDecision *outputs, uint32_t capacity);
#endif
