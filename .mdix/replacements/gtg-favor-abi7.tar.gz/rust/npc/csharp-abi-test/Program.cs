// Runs the Unity-side native layer (NPCNativeLib / NPCNativeTypes) against the real gtg_npc_ffi
// library and compares it with the managed fallback. Exit code 0 = all checks passed.
// Needs the native library on the loader path (LD_LIBRARY_PATH / DYLD_LIBRARY_PATH / PATH).
using System;
using System.Runtime.InteropServices;
using MidManStudio.Gtg.NPC.Components;
using MidManStudio.Gtg.NPC.Native;

namespace MidManStudio.Gtg.NPC.AbiTest
{
    internal static class Program
    {
        private const int Pool = 16384;
        private const ulong Seed = 0x47544700UL;
        private const ulong Seed2 = 0x47544701UL;
        private const ulong Seed3 = 0x47544702UL;
        private const ulong Seed4 = 0x47544703UL;
        private const int Actions = 12;
        private static int failures;

        private static void Check(bool ok, string what)
        {
            if (ok) return;
            failures++;
            Console.WriteLine("FAIL: " + what);
        }

        private static ulong Mix(ulong x)
        {
            unchecked
            {
                x += 0x9E3779B97F4A7C15UL;
                ulong z = (x ^ (x >> 30)) * 0xBF58476D1CE4E5B9UL;
                z = (z ^ (z >> 27)) * 0x94D049BB133111EBUL;
                return z ^ (z >> 31);
            }
        }

        // Same generator as crates/npc-ffi/examples/decision_throughput.rs and ffi-smoke-test/bench.c.
        private static NPCNativeObservation[] MixedPool()
        {
            var pool = new NPCNativeObservation[Pool];
            for (int i = 0; i < Pool; i++)
            {
                ulong r = Mix(Seed + (ulong)i);
                ulong r2 = Mix(Seed2 + (ulong)i);
                ulong r3 = Mix(Seed3 + (ulong)i);
                ulong r4 = Mix(Seed4 + (ulong)i);
                ulong pct = r % 100;
                uint role = pct < 12 ? 0u : pct < 50 ? 1u : pct < 62 ? 2u : pct < 82 ? 3u : pct < 90 ? 4u : 5u;
                uint sel = (uint)((r >> 8) % 2);
                ulong d = r2 % 100;
                pool[i] = new NPCNativeObservation
                {
                    NpcId = (ulong)i + 1,
                    Role = role,
                    Backend = role <= 1 ? 0u : role == 2 ? 1u : (role == 3 || role == 5) ? sel : 1u + sel,
                    ThreatVisible = ((r >> 16) % 100) < 25 ? 1u : 0u,
                    HealthFraction = (float)((r >> 24) % 1001) / 1000f,
                    CanMove = (role == 0 || ((r >> 40) % 100) < 10) ? 0u : 1u,
                    ThreatDistance = (float)((r4 >> 24) % 3001) / 100f,
                    Disposition = (byte)((role >= 2 && role <= 4) ? (d < 60 ? 0 : d < 85 ? 1 : 2) : 0),
                    Provoked = (byte)(((r2 >> 8) % 100) < 20 ? 1 : 0),
                    Level = (ushort)(1 + (r2 >> 16) % 30),
                    Order = (byte)(role == 5 ? (r2 >> 24) % 6 : 0),
                    OrderLevel = (ushort)(role == 5 ? (r2 >> 32) % 40 : 0),
                    Trustworthiness = role == 5 ? (float)(r3 % 1001) / 1000f : 0f,
                    Affinity = role == 5 ? (float)((r3 >> 12) % 1001) / 1000f : 0f,
                    PaySatisfaction = role == 5 ? (float)((r3 >> 24) % 1001) / 1000f : 0f,
                    Noise = role == 5 ? (uint)(r3 >> 32) : 0u,
                    BetrayalOpportunity = (byte)(role == 5 && (r2 >> 40) % 100 < 30 ? 1 : 0),
                    CrownHeat = (byte)(((r2 >> 48) % 100) < 55 ? 0 : ((r2 >> 48) % 100) < 75 ? 1 : ((r2 >> 48) % 100) < 90 ? 2 : 3),
                    AttackStyle = (byte)((r4 % 100) < 60 ? 0 : (r4 % 100) < 85 ? 1 : 2),
                    RangedReady = (byte)(((r4 >> 8) % 100) < 80 ? 1 : 0),
                    RangedStance = (byte)(((r4 >> 16) % 100) < 40 ? 1 : 0),
                    Favor = role <= 1 ? ((float)((r4 >> 32) % 2001UL) - 1000f) / 1000f : 0f
                };
            }
            return pool;
        }

        private static int Main()
        {
            // 1. Layout of the C# mirror structs (explicit layout, so this checks the declarations).
            Check(Marshal.SizeOf<NPCNativeObservation>() == 64, "observation size is 64");
            Check(Marshal.SizeOf<NPCNativeDecision>() == 16, "decision size is 16");
            string[] obsFields = { "NpcId", "Role", "Backend", "ThreatVisible", "HealthFraction", "CanMove", "ThreatDistance",
                "Disposition", "Order", "Provoked", "CrownHeat", "Level", "OrderLevel", "Trustworthiness", "Affinity", "PaySatisfaction",
                "Noise", "BetrayalOpportunity", "AttackStyle", "RangedReady", "RangedStance", "Favor" };
            int[] obsOffsets = { 0, 8, 12, 16, 20, 24, 28, 32, 33, 34, 35, 36, 38, 40, 44, 48, 52, 56, 57, 58, 59, 60 };
            for (int i = 0; i < obsFields.Length; i++)
                Check((int)Marshal.OffsetOf<NPCNativeObservation>(obsFields[i]) == obsOffsets[i], "observation offset of " + obsFields[i]);
            string[] decFields = { "NpcId", "Action", "Reserved" };
            int[] decOffsets = { 0, 8, 12 };
            for (int i = 0; i < decFields.Length; i++)
                Check((int)Marshal.OffsetOf<NPCNativeDecision>(decFields[i]) == decOffsets[i], "decision offset of " + decFields[i]);

            // 2. Real native calls. TryDecide returns false if the ABI version or struct sizes disagree,
            //    the library is missing, or the batch is rejected, so `true` proves the boundary works.
            var pool = MixedPool();
            const int Batch = 256; // same cap as NPCDecisionSystem
            var input = new NPCNativeObservation[Batch];
            var native = new NPCNativeDecision[Batch];
            var hist = new ulong[Actions];
            ulong hash = 0xcbf29ce484222325UL;
            long mismatches = 0;
            for (int off = 0; off < Pool; off += Batch)
            {
                Array.Copy(pool, off, input, 0, Batch);
                bool ok = NPCNativeLib.TryDecide(input, native, Batch);
                Check(ok, "native batch at offset " + off);
                if (!ok) { Console.WriteLine("Aborting: native library unusable."); return 1; }
                for (int i = 0; i < Batch; i++)
                {
                    var managed = NPCManagedFallback.Decide(input[i]);
                    if (native[i].NpcId != input[i].NpcId) { Check(false, "NpcId echoed for NPC " + input[i].NpcId); return 1; }
                    if (native[i].Reserved != 0) Check(false, "decision reserved is zero");
                    if (native[i].Action != managed.Action) mismatches++;
                    hist[native[i].Action]++;
                    unchecked { hash = (hash ^ (ulong)(native[i].Action + 1)) * 0x100000001b3UL; }
                }
            }
            Check(mismatches == 0, "managed fallback matches native for all " + Pool + " NPCs (" + mismatches + " differ)");
            foreach (ulong n in hist) Check(n > 0, "every action occurs in the mixed pool");
            var tiers = new ulong[4];
            foreach (var o in pool) tiers[o.CrownHeat]++;
            for (int t = 0; t < 4; t++) Check(tiers[t] > 0, "crown heat tier " + t + " occurs in the mixed pool");
            var styles = new ulong[3];
            foreach (var o in pool) styles[o.AttackStyle]++;
            for (int t = 0; t < 3; t++) Check(styles[t] > 0, "attack style " + t + " occurs in the mixed pool");
            ulong likedCount = 0, dislikedCount = 0;
            foreach (var o in pool) { if (o.Favor >= 0.2f) likedCount++; if (o.Favor < 0f) dislikedCount++; }
            Check(likedCount > 0 && dislikedCount > 0, "liked and disliked NPCs both occur in the mixed pool");
            Console.WriteLine("# mixed_actions idle={0} trade={1} patrol={2} attack={3} retreat={4} follow={5} hold={6} refuse={7} mission={8} betray={9} shoot={10} kite={11} fnv1a=0x{12:x16}",
                hist[0], hist[1], hist[2], hist[3], hist[4], hist[5], hist[6], hist[7], hist[8], hist[9], hist[10], hist[11], hash);

            // 3. Error paths through the real library.
            Check(NPCNativeLib.TryDecide(input, native, 0), "empty batch succeeds");
            bool threw = false;
            try { NPCNativeLib.TryDecide(input, native, NPCNativeLib.MaxBatch + 1); }
            catch (ArgumentOutOfRangeException) { threw = true; }
            Check(threw, "count above MaxBatch throws");
            Array.Copy(pool, 0, input, 0, 2);
            input[1].Role = 99;
            var sentinel = new NPCNativeDecision { NpcId = 999, Action = 77, Reserved = 9 };
            native[0] = sentinel; native[1] = sentinel;
            Check(!NPCNativeLib.TryDecide(input, native, 2), "invalid role is rejected");
            Check(native[0].Action == 77 && native[1].Action == 77, "rejected batch leaves outputs untouched");

            // Each field added since version 3 is validated by the native side. A bad value is rejected as a whole.
            string[] badNames = { "disposition 3", "order 6", "provoked 2", "crown heat 4", "attack style 3", "favor nan", "opportunity 2", "trust nan", "affinity infinity",
                "ranged ready 2", "ranged stance 2", "threat distance nan", "threat distance infinity", "favor infinity", "favor negative infinity" };
            for (int k = 0; k < badNames.Length; k++)
            {
                Array.Copy(pool, 0, input, 0, 2);
                switch (k)
                {
                    case 0: input[1].Disposition = 3; break;
                    case 1: input[1].Order = 6; break;
                    case 2: input[1].Provoked = 2; break;
                    case 3: input[1].CrownHeat = 4; break;
                    case 4: input[1].AttackStyle = 3; break;
                    case 5: input[1].Favor = float.NaN; break;
                    case 6: input[1].BetrayalOpportunity = 2; break;
                    case 7: input[1].Trustworthiness = float.NaN; break;
                    case 8: input[1].Affinity = float.PositiveInfinity; break;
                    case 9: input[1].RangedReady = 2; break;
                    case 10: input[1].RangedStance = 2; break;
                    case 11: input[1].ThreatDistance = float.NaN; break;
                    case 12: input[1].ThreatDistance = float.PositiveInfinity; break;
                    case 13: input[1].Favor = float.PositiveInfinity; break;
                    default: input[1].Favor = float.NegativeInfinity; break;
                }

                native[0] = sentinel; native[1] = sentinel;
                Check(!NPCNativeLib.TryDecide(input, native, 2) && native[0].Action == 77 && native[1].Action == 77, "native rejects " + badNames[k] + " and writes nothing");
            }

            // The refusal gap depends on the order type, and C# and Rust agree on it.
            // Level 10 accepts a delivery up to 16, an attack up to 13 and a raid up to 11.
            int[][] gapCases = { new[] { 4, 16, 8 }, new[] { 4, 17, 7 }, new[] { 3, 13, 5 }, new[] { 3, 14, 7 }, new[] { 5, 11, 8 }, new[] { 5, 12, 7 } };
            foreach (int[] c in gapCases)
            {
                input[0] = new NPCNativeObservation { NpcId = 5, Role = 5, Backend = 1, HealthFraction = 1f, CanMove = 1, Level = 10, Order = (byte)c[0], OrderLevel = (ushort)c[1], Trustworthiness = 1f, Affinity = 1f, PaySatisfaction = 1f };
                Check(NPCNativeLib.TryDecide(input, native, 1) && native[0].Action == c[2], "native: order " + c[0] + " at level " + c[1] + " gives action " + c[2] + ", got " + native[0].Action);
                Check(NPCManagedFallback.Decide(input[0]).Action == c[2], "fallback: order " + c[0] + " at level " + c[1] + " gives action " + c[2]);
            }

            // Crown Heat: a retaliatory guard that sees a threat ignores it at tier 0 and fights it from tier 1 on, and no
            // other role reads the tier. C# and Rust agree, and both tiers of every kind are checked on their own.
            for (byte tier = 0; tier <= 3; tier++)
            {
                foreach (uint role in new uint[] { 0, 1, 2, 3, 4, 5 })
                {
                    input[0] = new NPCNativeObservation { NpcId = 8, Role = role, Backend = 1, ThreatVisible = 1, HealthFraction = 1f, CanMove = 1, Level = 10, Disposition = 1, CrownHeat = tier };
                    int expected = role == 2 && tier >= 1 ? 3 : role == 3 || role == 4 ? 2 : role == 2 ? 2 : role == 0 ? 0 : role == 1 ? 4 : 5;
                    Check(NPCNativeLib.TryDecide(input, native, 1) && native[0].Action == expected, "native: role " + role + " retaliatory at crown heat " + tier + " gives " + expected + ", got " + native[0].Action);
                    Check(NPCManagedFallback.Decide(input[0]).Action == expected, "fallback: role " + role + " retaliatory at crown heat " + tier + " gives " + expected);
                }
            }

            // Attack styles. A hostile fighter that sees a threat at full health: melee always attacks, a ranged one
            // shoots, backs away inside the kite line and falls back when it has nothing to shoot, and a hybrid
            // switches on the distance band, holds its stance in the buffer, and fights by hand when it is empty.
            // Each row is style, ready, stance, can move, distance, expected action. C# and Rust agree on every row.
            // Distance 0 is "unknown", and a distance below 0 reaches the library as unknown too.
            object[][] styleRows =
            {
                new object[] { 0, 1, 0, 1, 2f, 3 }, new object[] { 0, 0, 1, 0, 50f, 3 },
                new object[] { 1, 1, 0, 1, 5.99f, 11 }, new object[] { 1, 1, 0, 1, 6f, 10 }, new object[] { 1, 1, 0, 1, 0f, 10 },
                new object[] { 1, 1, 0, 0, 2f, 10 }, new object[] { 1, 0, 0, 1, 20f, 4 }, new object[] { 1, 0, 0, 0, 20f, 0 },
                new object[] { 2, 1, 0, 1, 3.99f, 3 }, new object[] { 2, 1, 0, 1, 4f, 3 }, new object[] { 2, 1, 1, 1, 4f, 3 },
                new object[] { 2, 1, 0, 1, 8f, 10 }, new object[] { 2, 1, 0, 1, 7.99f, 3 }, new object[] { 2, 1, 1, 1, 7.99f, 10 },
                new object[] { 2, 1, 1, 1, 4.01f, 10 }, new object[] { 2, 1, 0, 1, 4.01f, 3 },
                new object[] { 2, 1, 0, 1, 0f, 3 }, new object[] { 2, 1, 1, 1, 0f, 10 }, new object[] { 2, 0, 1, 1, 20f, 3 }, new object[] { 2, 0, 0, 1, 20f, 3 }
            };
            foreach (object[] row in styleRows)
            {
                input[0] = new NPCNativeObservation
                {
                    NpcId = 31, Role = 3, Backend = 0, ThreatVisible = 1, HealthFraction = 1f, CanMove = (uint)(int)row[3], Level = 10,
                    AttackStyle = (byte)(int)row[0], RangedReady = (byte)(int)row[1], RangedStance = (byte)(int)row[2], ThreatDistance = (float)row[4]
                };
                int want = (int)row[5];
                string label = "style " + row[0] + " ready " + row[1] + " stance " + row[2] + " can move " + row[3] + " distance " + row[4];
                Check(NPCNativeLib.TryDecide(input, native, 1) && native[0].Action == want, "native: " + label + " gives " + want + ", got " + native[0].Action);
                Check(NPCManagedFallback.Decide(input[0]).Action == want, "fallback: " + label + " gives " + want);
            }

            // Shopkeepers. A merchant trades with nothing in view and stands still with a threat in view. Only one with the
            // retaliatory disposition that has been attacked fights back, in its own attack style, and at full health a
            // stationary one fights too. Each row is disposition, provoked, threat visible, can move, style, ready,
            // distance, expected action. The mixed pool above never gives a merchant a disposition, so these rows are the
            // check that C# and Rust agree on the rule.
            object[][] shopRows =
            {
                new object[] { 1, 0, 1, 0, 0, 0, 0f, 0 }, new object[] { 1, 1, 1, 0, 0, 0, 0f, 3 }, new object[] { 1, 1, 1, 1, 0, 0, 0f, 3 },
                new object[] { 1, 1, 0, 1, 0, 0, 0f, 1 }, new object[] { 1, 0, 0, 1, 0, 0, 0f, 1 },
                new object[] { 0, 1, 1, 1, 0, 0, 0f, 0 }, new object[] { 2, 1, 1, 1, 0, 0, 0f, 0 }, new object[] { 0, 0, 1, 1, 0, 0, 0f, 0 },
                new object[] { 1, 1, 1, 1, 1, 1, 20f, 10 }, new object[] { 1, 1, 1, 1, 1, 1, 3f, 11 }, new object[] { 1, 1, 1, 0, 1, 1, 3f, 10 },
                new object[] { 1, 1, 1, 1, 1, 0, 3f, 4 }, new object[] { 1, 1, 1, 0, 1, 0, 3f, 0 },
                new object[] { 1, 1, 1, 1, 2, 1, 2f, 3 }, new object[] { 1, 1, 1, 1, 2, 1, 12f, 10 }, new object[] { 1, 1, 1, 1, 2, 0, 12f, 3 },
                new object[] { 0, 1, 1, 1, 1, 1, 20f, 0 }, new object[] { 1, 0, 1, 1, 1, 1, 20f, 0 }, new object[] { 2, 1, 1, 1, 2, 1, 12f, 0 }
            };
            foreach (uint backend in new uint[] { 0, 1, 2 })
            {
                foreach (object[] row in shopRows)
                {
                    input[0] = new NPCNativeObservation
                    {
                        NpcId = 33, Role = 0, Backend = backend, ThreatVisible = (uint)(int)row[2], HealthFraction = 1f, CanMove = (uint)(int)row[3], Level = 10,
                        Disposition = (byte)(int)row[0], Provoked = (byte)(int)row[1],
                        AttackStyle = (byte)(int)row[4], RangedReady = (byte)(int)row[5], ThreatDistance = (float)row[6]
                    };
                    int want = (int)row[7];
                    string label = "shopkeeper backend " + backend + " disposition " + row[0] + " provoked " + row[1] + " threat " + row[2] + " can move " + row[3] +
                        " style " + row[4] + " ready " + row[5] + " distance " + row[6];
                    Check(NPCNativeLib.TryDecide(input, native, 1) && native[0].Action == want, "native: " + label + " gives " + want + ", got " + native[0].Action);
                    Check(NPCManagedFallback.Decide(input[0]).Action == want, "fallback: " + label + " gives " + want);
                }
            }

            // Favor. A shopkeeper or a civilian that likes the player (favor 0.2 or more) does not take the player for a
            // threat, unless the player has just attacked it. A retaliatory shopkeeper that was attacked still fights back.
            // A number above 1 counts as 1 and below -1 as -1 in the library, and the fallback reads it the same way.
            // Each row is role, favor, provoked, disposition, threat visible, can move, expected action.
            float justUnder = MathF.BitDecrement(0.2f);
            object[][] favorRows =
            {
                new object[] { 0u, 0f, 0, 0, 1, 0, 0 }, new object[] { 0u, 0.2f, 0, 0, 1, 0, 1 }, new object[] { 0u, justUnder, 0, 0, 1, 0, 0 },
                new object[] { 0u, 1f, 0, 0, 1, 0, 1 }, new object[] { 0u, -1f, 0, 0, 1, 0, 0 }, new object[] { 0u, 50f, 0, 0, 1, 0, 1 }, new object[] { 0u, -50f, 0, 0, 1, 0, 0 },
                new object[] { 0u, 1f, 1, 0, 1, 0, 0 }, new object[] { 0u, 1f, 1, 2, 1, 0, 0 }, new object[] { 0u, 1f, 1, 1, 1, 0, 3 },
                new object[] { 0u, -1f, 0, 0, 0, 0, 1 }, new object[] { 0u, 1f, 0, 0, 0, 0, 1 },
                new object[] { 1u, 0f, 0, 0, 1, 1, 4 }, new object[] { 1u, 0.2f, 0, 0, 1, 1, 2 }, new object[] { 1u, justUnder, 0, 0, 1, 1, 4 },
                new object[] { 1u, 1f, 0, 0, 1, 0, 0 }, new object[] { 1u, 1f, 1, 0, 1, 1, 4 }, new object[] { 1u, 1f, 1, 0, 1, 0, 0 },
                new object[] { 1u, -1f, 0, 0, 1, 1, 4 }, new object[] { 1u, 50f, 0, 0, 1, 1, 2 }, new object[] { 1u, 1f, 0, 0, 0, 1, 2 }
            };
            foreach (uint backend in new uint[] { 0, 1, 2 })
            {
                foreach (object[] row in favorRows)
                {
                    input[0] = new NPCNativeObservation
                    {
                        NpcId = 34, Role = (uint)row[0], Backend = backend, ThreatVisible = (uint)(int)row[4], HealthFraction = 1f, CanMove = (uint)(int)row[5], Level = 10,
                        Disposition = (byte)(int)row[3], Provoked = (byte)(int)row[2], Favor = (float)row[1]
                    };
                    int want = (int)row[6];
                    string label = "role " + row[0] + " backend " + backend + " favor " + row[1] + " provoked " + row[2] + " disposition " + row[3] + " threat " + row[4] + " can move " + row[5];
                    Check(NPCNativeLib.TryDecide(input, native, 1) && native[0].Action == want, "native: " + label + " gives " + want + ", got " + native[0].Action);
                    Check(NPCManagedFallback.Decide(input[0]).Action == want, "fallback: " + label + " gives " + want);
                }
            }

            // No other role reads favor, so favor changes nothing for them.
            foreach (uint role in new uint[] { 2, 3, 4, 5 })
            {
                foreach (byte disposition in new byte[] { 0, 1, 2 })
                {
                    var plain = new NPCNativeObservation { NpcId = 35, Role = role, Backend = 1, ThreatVisible = 1, HealthFraction = 1f, CanMove = 1, Level = 10, Disposition = disposition, Provoked = 1 };
                    var loved = plain; loved.Favor = 1f;
                    var hated = plain; hated.Favor = -1f;
                    input[0] = plain; Check(NPCNativeLib.TryDecide(input, native, 1), "native: plain batch"); int baseline = native[0].Action;
                    input[0] = loved; Check(NPCNativeLib.TryDecide(input, native, 1) && native[0].Action == baseline, "native: role " + role + " disposition " + disposition + " ignores a liked player");
                    input[0] = hated; Check(NPCNativeLib.TryDecide(input, native, 1) && native[0].Action == baseline, "native: role " + role + " disposition " + disposition + " ignores a hated player");
                    Check(NPCManagedFallback.Decide(loved).Action == baseline && NPCManagedFallback.Decide(hated).Action == baseline, "fallback: role " + role + " disposition " + disposition + " ignores favor");
                }
            }

            input[0] = new NPCNativeObservation { NpcId = 32, Role = 3, Backend = 0, ThreatVisible = 1, HealthFraction = 1f, CanMove = 1, Level = 10, AttackStyle = 1, RangedReady = 1, ThreatDistance = 2f };
            Check(NPCNativeLib.TryDecide(input, native, 1) && native[0].Action == 11, "native: a kiting ranged fighter at 2 m backs away");
            input[0].ThreatDistance = -2f;
            Check(NPCNativeLib.TryDecide(input, native, 1) && native[0].Action == 10, "native: a negative distance counts as unknown, so a ranged fighter shoots");
            Check(NPCManagedFallback.Decide(input[0]).Action == 10, "fallback: a negative distance counts as unknown, so a ranged fighter shoots");

            // The betrayal line, exactly. A companion with no loyalty has a chance of 0.5, so the roll
            // (noise >> 8 over 2^24) must be below 0.5. A roll exactly on the line does not betray.
            uint[] lineNoise = { 0x7FFFFFFFu, 0x80000000u, 0x7FFFFF00u, 0x80000100u };
            int[] lineExpected = { 9, -1, 9, -1 };
            for (int k = 0; k < lineNoise.Length; k++)
            {
                input[0] = new NPCNativeObservation { NpcId = 6, Role = 5, Backend = 1, HealthFraction = 1f, CanMove = 1, Level = 10, BetrayalOpportunity = 1, Noise = lineNoise[k] };
                bool betrays = lineExpected[k] == 9;
                Check(NPCNativeLib.TryDecide(input, native, 1) && (native[0].Action == 9) == betrays, "native: noise 0x" + lineNoise[k].ToString("X8") + (betrays ? " betrays" : " does not betray"));
                Check((NPCManagedFallback.Decide(input[0]).Action == 9) == betrays, "fallback: noise 0x" + lineNoise[k].ToString("X8") + (betrays ? " betrays" : " does not betray"));
            }

            // Off-screen mission resolution: the C# copy and the Rust library agree on every input tried, and both
            // reject the same bad input.
            ulong state = 0x1234567UL;
            long missionMismatches = 0, missionChecked = 0;
            var outcomes = new long[4];
            for (int i = 0; i < 200000; i++)
            {
                state = Mix(state);
                uint order = (state & 1) == 0 ? 4u : 5u;
                uint companionLevel = (uint)((state >> 8) % 60);
                uint missionLevel = (uint)((state >> 20) % 60);
                uint noise = (uint)(state >> 32);
                bool nativeOk = NPCNativeLib.TryResolveMission(order, companionLevel, missionLevel, noise, out int nativeOutcome);
                bool managedOk = NPCManagedMission.TryResolve(order, companionLevel, missionLevel, noise, out NpcMissionOutcome managedOutcome);
                if (!nativeOk || !managedOk || nativeOutcome != (int)managedOutcome) missionMismatches++;
                else outcomes[nativeOutcome]++;
                missionChecked++;
            }
            Check(missionMismatches == 0, "mission resolution matches between Rust and C# on " + missionChecked + " inputs (" + missionMismatches + " differ)");
            foreach (long n in outcomes) Check(n > 0, "every mission outcome occurs");
            Console.WriteLine("# missions success={0} failed={1} caught={2} killed={3}", outcomes[0], outcomes[1], outcomes[2], outcomes[3]);
            foreach (uint badOrder in new uint[] { 0, 1, 2, 3, 6, 99 })
            {
                Check(!NPCNativeLib.TryResolveMission(badOrder, 10, 10, 0, out _), "native rejects mission order " + badOrder);
                Check(!NPCManagedMission.TryResolve(badOrder, 10, 10, 0, out _), "fallback rejects mission order " + badOrder);
            }
            Check(!NPCNativeLib.TryResolveMission(5, 65536, 10, 0, out _) && !NPCManagedMission.TryResolve(5, 65536, 10, 0, out _), "both reject a companion level above 65535");
            Check(!NPCNativeLib.TryResolveMission(5, 10, 65536, 0, out _) && !NPCManagedMission.TryResolve(5, 10, 65536, 0, out _), "both reject a mission level above 65535");
            Check(NPCNativeLib.TryResolveMission(5, 65535, 65535, 0, out int largest) && largest == 0, "the largest levels are accepted");

            Console.WriteLine(failures == 0 ? "C# ABI test: PASS" : "C# ABI test: FAIL (" + failures + ")");
            return failures == 0 ? 0 : 1;
        }
    }
}
